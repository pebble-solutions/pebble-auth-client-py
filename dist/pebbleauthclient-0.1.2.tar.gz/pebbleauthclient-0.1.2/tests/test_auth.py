from pebbleauthclient.auth import auth

authToken = auth("test")

print(authToken)